cd ~/ffmpegbatch

for i in {0..9}
do
  echo "Scanning audio/video track $i"
  echo "Please wait"
  ffmpeg -i in/*.mp4 -map 0:v:$i -map 0:a:$i -c copy out/output$i.mp4
  echo "Track $i extracted"
  echo "\n"
done
echo "This script checks multitrack recording for 10 audio and video tracks. Existing tracks up to 10 (0-9) will always be extracted. Errors where stream cannot be found are the result of tracks not existing"
