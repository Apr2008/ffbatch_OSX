
echo "This app will install Homebrew and ffmpeg"
sleep 2
echo "-Homebrew is a free and open-source software package management system that simplifies the installation of software on Apple's operating system, macOS, as well as Linux."
sleep 3
echo "-ffmpeg is a complete, cross-platform solution to record, convert and stream audio and video."
sleep 2
echo "\n"

echo "**Sudo (Administrator) rights is required for successful operation of this script**"
echo "\n"

sleep 2
read -p "Press RETURN to continue with installation of Homebrew and ffmpeg [Enter]"
sleep 1
echo "Task 1: Install Homebrew"
sleep 2
echo "\n"

read -p "Press RETURN to install Homebrew [Enter]"
echo "Changing directory to home"
sleep .5
cd ~
echo "Successfully changed directory to home"
sleep 1
echo "Installing Homebrew"
/bin/bash -c "$(curl -fsSL https://raw.githubusercontent.com/Homebrew/install/HEAD/install.sh)"
echo "Checking Homebrew version"
brew update
sleep 1
echo "Upgrading Homebrew (if needed)"
brew upgrade
sleep 1
echo "Cleaning up Homebrew installation"
brew cleanup
echo "All clean!"
sleep 1
echo "Homebrew Installed!"
sleep 1
echo "\n"

echo "Task 2: Install ffmpeg"
sleep 2
echo "\n"

read -p "Press RETURN to install ffmpeg [Enter]. This will install a number of depedencies and will take up to 15 minutes to complete!!"
echo "Installing ffmpeg"
brew install ffmpeg --force
brew link ffmpeg
sleep 1.5
echo "**Disregard 'link' errors**"
echo "ffmpeg installed!"
echo "\n"

read -p "Press RETURN to exit [Enter]"
echo "Created by mInayR"
echo "Please close this terminal window, move unextracted .mp4 to 'in' folder, then run 'ffbatch'"
exit
